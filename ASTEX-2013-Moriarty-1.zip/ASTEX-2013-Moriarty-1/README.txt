First: Please excuse the naming convention of this assignment.
Second: For finding primes, used Sieve of Eratosthenes implementation based of example version in Algorithms (Sedgewick, Wayne), I modified it to work with Larger Integer values. It is in a seperate file because it takes about ~2 minutes to run. 


Clarification in the submission instructions need for next week.

The exercise sheet 1-1 has been distributed in class.

Proceed as follows:
Create a directory named "ASTEX-", where you replace with your last name.
## Replace what part of that with our name?

Create a subdirectory for each exercise named "exercise" where is replaced with the three-digit number of the exercise.
## Exercises were not numbered in a three digit format.
## Again, where what is replaced? creating exercise folders name "#" where # is replaced with execise number. Ommiting extra padding to create 3 digit numbers and the word exercise. 

Put all files required to solve the exercise in the respective subdirectory. Create suitable subdirectories where appropriate.

Solve the problem posed, create, compile, run and test the code.

Name the main source file and the executable "exercise" (with suitable extension).

Add a README.txt when appropriate.
## This is why this README.txt is here

Zip the subdirectories of the exercise problems to be solved for an exercise sheet
into a single zip file named "ASTEX-2013-ST--Sheet--.zip"
Upload before the due date.
## Assumeing the ST = Student's name, and Sheet is 1, not 1-1
## Removing excess -'s from folder name. 

